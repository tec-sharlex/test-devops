# youtube_notes
Aws devops and linux 
use it 
let me know if mistakes in the notes or in the youtube videos 
